FRESH LIVE STAFF SCHEDULER - NETLIFY SETUP

Recommended deployment method (most reliable):
1. Create a new GitHub repository.
2. Upload every file and folder from this project to the repository.
3. In Netlify, choose Add new project > Import an existing project.
4. Select GitHub and choose the repository.
5. Netlify should detect netlify.toml automatically.
6. Deploy the site.

After deployment:
- Open https://YOUR-SITE.netlify.app/api/schedule
- A working server returns JSON containing "ok": true.
- Open the normal site. The status should say "Live · saved online".

Features:
- Monday to Sunday columns
- Add/edit/delete jobs
- Drag jobs between days
- Add/rename/delete staff
- Drag staff to multiple jobs and days
- Add/rename/delete vehicles
- Drag vehicles to jobs
- Shared live online saving
- Local fallback saving
- Weekly schedules
- Backup and restore
- Printing
